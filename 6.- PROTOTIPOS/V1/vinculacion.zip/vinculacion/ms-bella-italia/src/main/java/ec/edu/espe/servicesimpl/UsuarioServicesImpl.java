package ec.edu.espe.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Service;

import ec.edu.espe.modelo.Usuario;
import ec.edu.espe.repository.UsuarioRepository;
import ec.edu.espe.services.UsuarioServices;

@Service
public class UsuarioServicesImpl  implements UsuarioServices{
	
	@Autowired
	private UsuarioRepository usuariosRepository;

	@Override
	public Usuario saveUsuario(Usuario objUsuario) throws Exception {
		usuariosRepository.save(objUsuario);
		return objUsuario;
	}

	@Override
	public List<Usuario> ListAll() {
		
		return usuariosRepository.findAll();
	}

	@Override
	public Usuario getById(Long id) {
		Usuario us = usuariosRepository.findById(id).orElse(null);
		return us;
				
	}
	
	
	

}
