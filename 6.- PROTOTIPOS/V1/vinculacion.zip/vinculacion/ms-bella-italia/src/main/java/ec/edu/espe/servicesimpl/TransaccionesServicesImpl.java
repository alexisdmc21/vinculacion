package ec.edu.espe.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ec.edu.espe.modelo.Transacciones;
import ec.edu.espe.repository.TransaccionesRepository;
import ec.edu.espe.services.TransaccionesServices;

@ Service
public class TransaccionesServicesImpl implements TransaccionesServices{
	
	
	@Autowired
	private TransaccionesRepository transaccionesRepository;

	public Transacciones saveRol(Transacciones objRol) throws Exception {
		return null;
	}

	@Override
	public List<Transacciones> listAll() {
		List<Transacciones> transacciones = transaccionesRepository.findAll();
		return transacciones;
	}

	@Override
	public Transacciones saveTransacciones(Transacciones objTransacciones) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
