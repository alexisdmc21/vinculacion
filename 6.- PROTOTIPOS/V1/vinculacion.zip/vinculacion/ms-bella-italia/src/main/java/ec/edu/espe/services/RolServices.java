package ec.edu.espe.services;

import java.util.List;

import ec.edu.espe.modelo.Rol;

public interface RolServices {

	Rol saveRol(Rol objRol) throws Exception;

	List<Rol> listAll();

}
