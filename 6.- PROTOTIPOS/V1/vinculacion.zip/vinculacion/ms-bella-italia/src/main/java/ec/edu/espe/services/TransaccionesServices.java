package ec.edu.espe.services;

import java.util.List;

import ec.edu.espe.modelo.Transacciones;

public interface TransaccionesServices {
	
	Transacciones saveTransacciones(Transacciones objTransacciones) throws Exception;
	
	List<Transacciones> listAll();

}
