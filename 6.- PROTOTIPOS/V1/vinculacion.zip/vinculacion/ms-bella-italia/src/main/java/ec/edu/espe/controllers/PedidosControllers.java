package ec.edu.espe.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Pedidos;
import ec.edu.espe.services.PedidosServices;

@RestController
@RequestMapping("/pedidos")
@CrossOrigin("*") 



public class PedidosControllers {

	@Autowired
	private PedidosServices servicesPedidos;
	
	@GetMapping("/")
	public List<Pedidos> getAll() {
		return servicesPedidos.listAll();	
	}
	
	// Obtener un pedido por ID
    @GetMapping("/{id}")
    public ResponseEntity<Pedidos> getById(@PathVariable String id) {
        Optional<Pedidos> pedido = servicesPedidos.findById(id);
        if (pedido.isPresent()) {
            return ResponseEntity.ok(pedido.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

 // Método para buscar pedidos por texto
    @GetMapping("/search")
    public ResponseEntity<List<Pedidos>> searchByText(@RequestParam String text) {
        List<Pedidos> pedidos = servicesPedidos.searchByText(text);
        if (!pedidos.isEmpty()) {
            return ResponseEntity.ok(pedidos);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    
    
    // Crear un nuevo pedido
    @PostMapping("/")
    public Pedidos create(@RequestBody Pedidos pedido) {
        return servicesPedidos.save(pedido);
    }

    // Actualizar un pedido existente
    @PutMapping("/{id}")
    public ResponseEntity<Pedidos> update(@PathVariable String id, @RequestBody Pedidos pedidoDetails) {
        Optional<Pedidos> pedidoData = servicesPedidos.findById(id);

        if (pedidoData.isPresent()) {
            Pedidos pedido = pedidoData.get();
            pedido.setCliente(pedidoDetails.getCliente()); // Asumiendo que Pedidos tiene un atributo cliente
            pedido.setTotal(pedidoDetails.getTotal());     // Asumiendo que Pedidos tiene un atributo total
            return ResponseEntity.ok(servicesPedidos.save(pedido));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un pedido
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable String id) {
        try {
            servicesPedidos.delete(id);
            return ResponseEntity.ok("Pedido eliminado con éxito");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error al eliminar el pedido: " + e.getMessage());
        }
    }
}
