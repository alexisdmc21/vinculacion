package ec.edu.espe.services;

import java.util.List;

import ec.edu.espe.modelo.Usuario;

public interface UsuarioServices {
	
	Usuario saveUsuario(Usuario objUsuario) throws Exception;
	List<Usuario> ListAll();
	
	Usuario getById(Long id);

}
