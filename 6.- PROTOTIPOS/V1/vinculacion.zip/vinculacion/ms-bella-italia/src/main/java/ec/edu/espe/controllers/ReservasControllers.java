package ec.edu.espe.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Reservas;
import ec.edu.espe.services.ReservasServices;


@RestController
@RequestMapping("/resevas")
@CrossOrigin("*") 
public class ReservasControllers {

	@Autowired
	private ReservasServices servicesReservas;
	
	
	// Obtener todas las reservas
    @GetMapping("/")
    public List<Reservas> getAll() {
        return servicesReservas.listAll();
    }

    // Obtener una reserva por su ID
    @GetMapping("/{id}")
    public Reservas getById(@PathVariable("id") Long id) {
        return servicesReservas.getById(id);
    }

    // Crear una nueva reserva
    @PostMapping("/")
    public Reservas create(@RequestBody Reservas reserva) {
        return servicesReservas.create(reserva);
    }

    // Actualizar una reserva existente
    @PutMapping("/{id}")
    public Reservas update(@PathVariable("id") Long id, @RequestBody Reservas reserva) {
        return servicesReservas.update(id, reserva);
    }

    // Eliminar una reserva por su ID
    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") Long id) {
        servicesReservas.delete(id);
    }

    // Buscar reservas por texto en cualquier campo relevante
    @GetMapping("/buscar")
    public List<Reservas> buscarPorTexto(@RequestParam("texto") String texto) {
        return servicesReservas.buscarPorTexto(texto);
    }
}
