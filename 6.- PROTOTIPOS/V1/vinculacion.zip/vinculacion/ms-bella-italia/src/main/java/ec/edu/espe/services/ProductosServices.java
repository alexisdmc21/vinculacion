package ec.edu.espe.services;

import java.util.List;
import java.util.Optional;

import ec.edu.espe.modelo.Productos;

public interface ProductosServices {

	Productos saveProductos(Productos objProductos) throws Exception;

    List<Productos> listAll();

    Optional<Productos> findById(Long id);

    Productos save(Productos productos);

    void deleteById(Long id);

    boolean existsById(Long id);
	
    List<Productos> findByNombre(String nombre); // Método para buscar por nombre
    

}
