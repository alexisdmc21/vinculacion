package ec.edu.espe.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.espe.modelo.Mesas;

public interface MesasRepository extends JpaRepository <Mesas, Long>{

	 Mesas findByNumero(int numero);
	    List<Mesas> findByNombreContainingIgnoreCase(String nombre); // Método para buscar por nombre (caso insensible)
}
