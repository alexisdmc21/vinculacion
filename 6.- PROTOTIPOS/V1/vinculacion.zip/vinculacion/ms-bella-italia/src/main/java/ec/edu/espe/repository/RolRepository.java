package ec.edu.espe.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.espe.modelo.Rol;


public interface RolRepository extends JpaRepository <Rol, Long>{
	
	

}
