package ec.edu.espe.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Provedores;
import ec.edu.espe.services.ProvedoresServices;


@RestController
@RequestMapping("/provedores")
@CrossOrigin("*") 

public class ProvedoresControllers {

	
	@Autowired
    private ProvedoresServices servicesProvedores;
    
    @GetMapping("/")
    public List<Provedores> getAll() {
        return servicesProvedores.listAll();
    }
    
    @GetMapping("/{id}")
    public Provedores getById(@PathVariable Long id) {
        Optional<Provedores> provedores = servicesProvedores.findById(id);
        return provedores.orElse(null);
    }
    
    @PostMapping("/")
    public Provedores create(@RequestBody Provedores provedores) {
        return servicesProvedores.save(provedores); 
    }
    
    @PutMapping("/{id}")
    public Provedores update(@PathVariable Long id, @RequestBody Provedores provedores) {
        provedores.setId(id);
        return servicesProvedores.update(provedores);
    }
    
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        servicesProvedores.delete(id);
    }
	 
    @GetMapping("/nombre/{nombre}")
    public List<Provedores> getByNombre(@PathVariable String nombre) {
        return servicesProvedores.findByNombre(nombre);
    }
}
