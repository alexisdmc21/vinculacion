package ec.edu.espe.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Usuario;
import ec.edu.espe.services.UsuarioServices;


@RestController
@RequestMapping("/usuario")
@CrossOrigin("*") 

public class UsuarioControllers {

	@Autowired
	private UsuarioServices servicesUsuario;
	
	
	
	
	@GetMapping("/")
	public List<Usuario> getAll() {
		return servicesUsuario.ListAll();
		
	}
}
