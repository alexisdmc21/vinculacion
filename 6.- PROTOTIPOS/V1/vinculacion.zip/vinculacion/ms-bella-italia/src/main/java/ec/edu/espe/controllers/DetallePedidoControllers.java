package ec.edu.espe.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.DetallePedidos;
import ec.edu.espe.services.DetallePedidoServices;

@RestController
@RequestMapping("/detallepedido")
@CrossOrigin("*")


public class DetallePedidoControllers {

	@Autowired
	private DetallePedidoServices servicesdeDetallePedido;
	
	
	
	
	@GetMapping("/")
	public List<DetallePedidos> getAll() {
		return servicesdeDetallePedido.listAll();
		
	}
	
	
}
