package ec.edu.espe.services;

import java.util.List;

import ec.edu.espe.modelo.Reservas;
import ec.edu.espe.modelo.Rol;

public interface ReservasServices {

	Reservas saveReservas(Rol objReservas) throws Exception;

	List<Reservas> listAll();
	
	Reservas getById(Long id);

    Reservas create(Reservas reserva);

    Reservas update(Long id, Reservas reserva);

    void delete(Long id);

    List<Reservas> buscarPorTexto(String texto);
    
}
