package ec.edu.espe.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "usuarios")
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String nombre;
	private String apellido;
	private String telefono;
	private String corrreo;
	private String ciudad;
	private String direccion;
	private String cedula;
	private String password;

	@ManyToOne
	@JoinColumn(name = "id_rol")
	private Rol rol;
	
	
	
	

	/**
	 * @param id
	 * @param nombre
	 * @param apellido
	 * @param telefono
	 * @param corrreo
	 * @param ciudad
	 * @param direccion
	 * @param cedula
	 * @param password
	 * @param rol
	 */
	public Usuario(long id, String nombre, String apellido, String telefono, String corrreo, String ciudad,
			String direccion, String cedula, String password, Rol rol) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.telefono = telefono;
		this.corrreo = corrreo;
		this.ciudad = ciudad;
		this.direccion = direccion;
		this.cedula = cedula;
		this.password = password;
		this.rol = rol;
	}

	/**
	 * @param id
	 * @param nombre
	 * @param apellido
	 * @param telefono
	 * @param corrreo
	 * @param ciudad
	 * @param direccion
	 * @param cedula
	 * @param password
	 */
	public Usuario(long id, String nombre, String apellido, String telefono, String corrreo, String ciudad,
			String direccion, String cedula, String password) {
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.telefono = telefono;
		this.corrreo = corrreo;
		this.ciudad = ciudad;
		this.direccion = direccion;
		this.cedula = cedula;
		this.password = password;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellido
	 */
	public String getApellido() {
		return apellido;
	}

	/**
	 * @param apellido the apellido to set
	 */
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	/**
	 * @return the telefono
	 */
	public String getTelefono() {
		return telefono;
	}

	/**
	 * @param telefono the telefono to set
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	/**
	 * @return the corrreo
	 */
	public String getCorrreo() {
		return corrreo;
	}

	/**
	 * @param corrreo the corrreo to set
	 */
	public void setCorrreo(String corrreo) {
		this.corrreo = corrreo;
	}

	/**
	 * @return the ciudad
	 */
	public String getCiudad() {
		return ciudad;
	}

	/**
	 * @param ciudad the ciudad to set
	 */
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	/**
	 * @return the cedula
	 */
	public String getCedula() {
		return cedula;
	}

	/**
	 * @param cedula the cedula to set
	 */
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the rol
	 */
	public Rol getRol() {
		return rol;
	}

	/**
	 * @param rol the rol to set
	 */
	public void setRol(Rol rol) {
		this.rol = rol;
	}

	
	
	
	

}
