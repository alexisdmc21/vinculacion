package ec.edu.espe.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.espe.modelo.Productos;

public interface ProductosRepository extends JpaRepository <Productos, Long> {

	List<Productos> findByNombre(String nombre); // Método para buscar por nombre

}

