package ec.edu.espe.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ec.edu.espe.modelo.Mesas;
import ec.edu.espe.repository.MesasRepository;
import ec.edu.espe.services.MesasServices;


@Service
public class MesasServicesImpl implements MesasServices {

	@Autowired
	private MesasRepository mesasRepository;
	

	 @Override
	    public Mesas saveMesas(Mesas objMesas) throws Exception {
	        return mesasRepository.save(objMesas);
	    }

	    @Override
	    public List<Mesas> listAll() {
	        return mesasRepository.findAll();
	    }

	    @Override
	    public Mesas findByNumero(int numero) {
	        return mesasRepository.findByNumero(numero);
	    }

	    @Override
	    public void deleteMesas(int id) {
	        mesasRepository.deleteById((long) id); // Convertir id a Long
	    }

	    @Override
	    public Mesas updateMesas(int id, Mesas objMesas) {
	        Mesas existingMesas = mesasRepository.findById((long) id).orElse(null); // Convertir id a Long
	        if (existingMesas != null) {
	            existingMesas.setNumero(objMesas.getNumero());
	            existingMesas.setCapacidad(objMesas.getCapacidad());
	            // Actualiza más campos si es necesario
	            return mesasRepository.save(existingMesas);
	        }
	        return null;
	    }

	    @Override
	    public List<Mesas> findByTexto(String texto) {
	        return mesasRepository.findByNombreContainingIgnoreCase(texto);
	    }
}
