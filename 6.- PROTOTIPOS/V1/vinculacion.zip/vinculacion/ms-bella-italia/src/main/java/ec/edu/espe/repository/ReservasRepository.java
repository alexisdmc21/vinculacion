package ec.edu.espe.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.espe.modelo.Reservas;

public interface ReservasRepository extends JpaRepository <Reservas, Long>{
	
	List<Reservas> findByNombreContains(String texto);

}
