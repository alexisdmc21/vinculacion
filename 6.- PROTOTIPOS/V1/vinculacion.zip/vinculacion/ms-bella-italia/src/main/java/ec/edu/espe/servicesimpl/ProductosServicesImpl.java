package ec.edu.espe.servicesimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ec.edu.espe.modelo.Productos;
import ec.edu.espe.repository.ProductosRepository;
import ec.edu.espe.services.ProductosServices;


@Service
public class ProductosServicesImpl implements ProductosServices{

	@Autowired
    private ProductosRepository productosRepository;

    @Override
    public Productos saveProductos(Productos objProductos) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Productos> listAll() {
        return productosRepository.findAll();
    }

    @Override
    public Optional<Productos> findById(Long id) {
        return productosRepository.findById(id);
    }

    @Override
    public Productos save(Productos productos) {
        return productosRepository.save(productos);
    }

    @Override
    public void deleteById(Long id) {
        productosRepository.deleteById(id);
    }

    @Override
    public boolean existsById(Long id) {
        return productosRepository.existsById(id);
    }

    @Override
    public List<Productos> findByNombre(String nombre) {
        return productosRepository.findByNombre(nombre);
    }
}
