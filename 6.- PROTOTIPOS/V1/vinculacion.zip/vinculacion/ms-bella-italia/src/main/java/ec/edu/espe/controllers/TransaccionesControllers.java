package ec.edu.espe.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Transacciones;
import ec.edu.espe.services.TransaccionesServices;


@RestController
@RequestMapping("/transaciones")
@CrossOrigin("*") 

public class TransaccionesControllers {

	@Autowired
	private TransaccionesServices servicesTransacciones;
	
	
	
	
	@GetMapping("/")
	public List<Transacciones> getAll() {
		return servicesTransacciones.listAll();
		
		}

}
/*
	public TransaccionesServices getServicesTransacciones() {
		return servicesTransacciones;
	}




	public void setServicesTransacciones(TransaccionesServices servicesTransacciones) {
		this.servicesTransacciones = servicesTransacciones;
	}
	
	
}*/
