package ec.edu.espe.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Productos;
import ec.edu.espe.services.ProductosServices;

@RestController
@RequestMapping("/Productos")
@CrossOrigin("*") 

public class ProductosControllers {

	@Autowired
	private ProductosServices servicesProductos;
	
	
	
	
	@GetMapping("/")
	public List<Productos> getAll() {
		return servicesProductos.listAll();
			
		
	}
	

	@GetMapping("/{id}")
    public ResponseEntity<Productos> getById(@PathVariable Long id) {
        Optional<Productos> productos = servicesProductos.findById(id);
        return productos.map(ResponseEntity::ok)
                         .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/")
    public ResponseEntity<Productos> create(@RequestBody Productos productos) {
        Productos createdProductos = servicesProductos.save(productos);
        return ResponseEntity.ok(createdProductos);
    }
    
    
    @PutMapping("/{id}")
    public ResponseEntity<Productos> update(@PathVariable Long id, @RequestBody Productos productos) {
        Optional<Productos> optionalProductos = servicesProductos.findById(id);
        if (optionalProductos.isPresent()) {
            Productos existingProductos = optionalProductos.get();
            existingProductos.setNombre(productos.getNombre());
            existingProductos.setPrecio(productos.getPrecio());
            existingProductos.setCantidad(productos.getCantidad());
            Productos updatedProductos = servicesProductos.save(existingProductos);
            return ResponseEntity.ok(updatedProductos);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (servicesProductos.existsById(id)) {
            servicesProductos.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
