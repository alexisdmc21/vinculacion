package ec.edu.espe.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ec.edu.espe.modelo.DetallePedidos;
import ec.edu.espe.repository.DetallePedidoRepository;
import ec.edu.espe.services.DetallePedidoServices;


@Service
public class DetallePedidoServiceImpl implements DetallePedidoServices {

	@Autowired
	private DetallePedidoRepository detallePedidoRepository;
	

	@Override
	public DetallePedidos saveDetallePedido(DetallePedidos objDetallePedido) throws Exception {
		
		return null;
	}

	@Override
	public List<DetallePedidos> listAll() {
		List<DetallePedidos> detallepedido = detallePedidoRepository.findAll();
		return detallepedido;
	}

}
