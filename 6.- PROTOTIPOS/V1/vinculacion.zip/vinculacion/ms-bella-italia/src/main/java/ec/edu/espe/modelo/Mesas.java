package ec.edu.espe.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "mesas")
@NoArgsConstructor
@AllArgsConstructor


public class Mesas {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "Mesa")	
	private int numero;
	private int capacidad;
	private String estado;//ocupado, reservado, en limpieza
	
	
	
	
	
	
	/**
	 * @param id
	 * @param numero
	 * @param capacidad
	 * @param estado
	 */
	public Mesas(long id, int numero, int capacidad, String estado) {
		this.id = id;
		this.numero = numero;
		this.capacidad = capacidad;
		this.estado = estado;
	}
	/**
	 * @param numero
	 * @param capacidad
	 * @param estado
	 */
	public Mesas(int numero, int capacidad, String estado) {
		this.numero = numero;
		this.capacidad = capacidad;
		this.estado = estado;
	}
	/**
	 * 
	 */
	public Mesas() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the numero
	 */
	public int getNumero() {
		return numero;
	}
	/**
	 * @param numero the numero to set
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}
	/**
	 * @return the capacidad
	 */
	public int getCapacidad() {
		return capacidad;
	}
	/**
	 * @param capacidad the capacidad to set
	 */
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}
	

	
	
	
	
	
}
