package ec.edu.espe.services;

import java.util.List;

import ec.edu.espe.modelo.DetallePedidos;

public interface DetallePedidoServices {

	
	DetallePedidos saveDetallePedido(DetallePedidos objDetallePedido) throws Exception;

	List<DetallePedidos> listAll();
}
