package ec.edu.espe.modelo;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "reservas")
@NoArgsConstructor
@AllArgsConstructor

public class Reservas {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@Column(name = "Reserva")
	private long cliente;
	private long mesa;
	private Date reservaMesa;
	
		
	@ManyToOne
	@JoinColumn(name = "mesas")
	private Mesas mesas;
	
	@ManyToOne
	@JoinColumn(name = "usuario")
	private Usuario usuarios;
	
	
	
	
	
	
	/**
	 * @param id
	 * @param Usuario
	 * @param mesa
	 * @param reservaMesa
	 */
	public Reservas(long id, long cliente, long mesa, Date reservaMesa) {
		super();
		this.id = id;
		this.cliente = cliente;
		this.mesa = mesa;
		this.reservaMesa = reservaMesa;
		
		
	}
	/**
	 * 
	 */
	public Reservas() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the Usuario
	 */
	public long getCliente() {
		return cliente;
	}
	/**
	 * @param Usuario the Usuario to set
	 */
	public void setCliente(long cliente) {
		this.cliente = cliente;
	}
	/**
	 * @return the mesa
	 */
	public long getMesa() {
		return mesa;
	}
	/**
	 * @param mesa the mesa to set
	 */
	public void setMesa(long mesa) {
		this.mesa = mesa;
	}
	/**
	 * @return the reservaMesa
	 */
	public Date getReservaMesa() {
		return reservaMesa;
	}
	/**
	 * @param reservaMesa the reservaMesa to set
	 */
	public void setReservaMesa(Date reservaMesa) {
		this.reservaMesa = reservaMesa;
	}
	
	
	
	
}
