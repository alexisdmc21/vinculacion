package ec.edu.espe.modelo;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inventario")
@NoArgsConstructor
@AllArgsConstructor
@Data

public class Inventario {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	
	@Column(name = "Inventario")
	private long id;
	
	private String nombre;
	private String cantidad;
	
	@Column(name = "id_provedor")
	private long idProvedor;
	private double precio;
	
	 @Column(name = "fecha_ingreso")
	private Date fechaIngreso;
	
	
	@ManyToOne
    @JoinColumn(name = "id_provedores", nullable = false)
    private long provedores;
	
	
	 @ManyToOne
	    @JoinColumn(name = "id_productos", nullable = false)
	    private Productos productos;


	/**
	 * @param id
	 * @param nombre
	 * @param cantidad
	 * @param idProvedor
	 * @param precio
	 * @param fechaIngreso
	 * @param provedores
	 * @param productos
	 */
	public Inventario(long id, String nombre, String cantidad, long idProvedor, double precio, Date fechaIngreso,
			long provedores, Productos productos) {
		this.id = id;
		this.nombre = nombre;
		this.cantidad = cantidad;
		this.idProvedor = idProvedor;
		this.precio = precio;
		this.fechaIngreso = fechaIngreso;
		this.provedores = provedores;
		this.productos = productos;
	}


	/**
	 * 
	 */
	public Inventario() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}


	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}


	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	/**
	 * @return the cantidad
	 */
	public String getCantidad() {
		return cantidad;
	}


	/**
	 * @param cantidad the cantidad to set
	 */
	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}


	/**
	 * @return the idProvedor
	 */
	public long getIdProvedor() {
		return idProvedor;
	}


	/**
	 * @param idProvedor the idProvedor to set
	 */
	public void setIdProvedor(long idProvedor) {
		this.idProvedor = idProvedor;
	}


	/**
	 * @return the precio
	 */
	public double getPrecio() {
		return precio;
	}


	/**
	 * @param precio the precio to set
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}


	/**
	 * @return the fechaIngreso
	 */
	public Date getFechaIngreso() {
		return fechaIngreso;
	}


	/**
	 * @param fechaIngreso the fechaIngreso to set
	 */
	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}


	/**
	 * @return the provedores
	 */
	public long getProvedores() {
		return provedores;
	}


	/**
	 * @param provedores the provedores to set
	 */
	public void setProvedores(long provedores) {
		this.provedores = provedores;
	}


	/**
	 * @return the productos
	 */
	public Productos getProductos() {
		return productos;
	}


	/**
	 * @param productos the productos to set
	 */
	public void setProductos(Productos productos) {
		this.productos = productos;
	}




	
	
	
	
	
	
	
}
