package ec.edu.espe.servicesimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import ec.edu.espe.modelo.Pedidos;
import ec.edu.espe.repository.PedidosRepository;
import ec.edu.espe.services.PedidosServices;

public class PedidosServicesImpl  implements PedidosServices{

	@Autowired
	private PedidosRepository pedidosRepository;
	
	@Override
	public Pedidos savePedidos(Pedidos objPedidos) throws Exception {
		
		return pedidosRepository.save(objPedidos);
	}

	 @Override
	    public List<Pedidos> listAll() {
	        return pedidosRepository.findAll();
	    }


	    @Override
	    public Optional<Pedidos> findById(String id) {
	        Long parsedId = Long.parseLong(id); // Convertir String a Long
	        return pedidosRepository.findById(parsedId);
	    }

	    @Override
	    public Pedidos save(Pedidos pedido) {
	        return pedidosRepository.save(pedido);
	    }

	    @Override
	    public void delete(String id) {
	        Long parsedId = Long.parseLong(id); // Convertir String a Long
	        pedidosRepository.deleteById(parsedId);
	    }

	    @Override
	    public List<Pedidos> searchByText(String text) {
	        // Implementa la búsqueda según tus necesidades
	        return pedidosRepository.findByClienteContainingOrDetalleContaining(text, text);
	    }

	    @Override
	    public boolean existsById(Long id) {
	        return pedidosRepository.existsById(id);
	    }
}
