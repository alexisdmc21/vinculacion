package ec.edu.espe.services;

import java.util.List;
import java.util.Optional;

import ec.edu.espe.modelo.Provedores;

public interface ProvedoresServices {

	Provedores saveProvedores(Provedores objProvedores) throws Exception;

	List<Provedores> listAll();
	Optional<Provedores> findById(Long id);
    	Provedores save(Provedores provedores);
    	Provedores update(Provedores provedores);
    void delete(Long id);
    List<Provedores> findByNombre(String nombre); // Método para buscar por nombre
}
