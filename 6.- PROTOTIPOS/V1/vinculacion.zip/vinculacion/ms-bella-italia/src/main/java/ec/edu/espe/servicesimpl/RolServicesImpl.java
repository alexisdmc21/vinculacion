package ec.edu.espe.servicesimpl;

import java.util.List;

//import javax.management.relation.Role;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ec.edu.espe.modelo.Rol;
import ec.edu.espe.repository.RolRepository;
import ec.edu.espe.services.RolServices;

@Service
public class RolServicesImpl implements RolServices {
	
	@Autowired
	private RolRepository rolRepository;

	@Override
	public Rol saveRol(Rol objRol) throws Exception {
		return null;
	}

	@Override
	public List<Rol> listAll() {
		List<Rol> roles = rolRepository.findAll();
		return roles;
	}


}
