/**
 * 
 */
package ec.edu.espe.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.espe.modelo.Rol;
import ec.edu.espe.services.RolServices;

@RestController
@RequestMapping("/roles")
@CrossOrigin("*") 

public class RolControllers {

	@Autowired
	private RolServices servicesRol;
	
	
	
	
	@GetMapping("/")
	public List<Rol> getAll() {
		return servicesRol.listAll();
		
	}
	
}
