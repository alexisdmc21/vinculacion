package ec.edu.espe.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import ec.edu.espe.modelo.Reservas;
import ec.edu.espe.repository.ReservasRepository;

public class ReservasServicesImpl {

	
	@Autowired
	private ReservasRepository reservasRepository;

	//@Override-----
	public Reservas saveRol(Reservas objReservas) throws Exception {
		return null;
	}

	public List<Reservas> listAll() {
        return reservasRepository.findAll();
    }

   
    public Reservas getById(Long id) {
        return reservasRepository.findById(id).orElse(null);
    }

   
    public Reservas create(Reservas reserva) {
        return reservasRepository.save(reserva);
    }

   
    public Reservas update(Long id, Reservas reserva) {
        if (reservasRepository.existsById(id)) {
            reserva.setId(id);
            return reservasRepository.save(reserva);
        }
        return null; // O manejar el error de otra manera
    }

   
    public void delete(Long id) {
        reservasRepository.deleteById(id);
    }

   
    public List<Reservas> buscarPorTexto(String texto) {
        // Implementa la lógica para buscar reservas por texto
        return reservasRepository.findByNombreContains(texto); // Ejemplo: buscar por nombre que contenga el texto
    }

	
	
	
}
