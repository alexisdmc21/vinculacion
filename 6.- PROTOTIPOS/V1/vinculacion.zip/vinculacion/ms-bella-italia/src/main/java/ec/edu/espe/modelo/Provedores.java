package ec.edu.espe.modelo;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "provedores")
@NoArgsConstructor
@AllArgsConstructor
@Data/////
public class Provedores {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	
	@Column(name = "Provedor")
	private long id;
	private int cantidad;
	private long id_provedor;
	private float precioCompra;
	
	@Column(name = "fecha_ingreso")
	private Date fechaIngreso;

	
	@OneToMany
	private List<Inventario> inventario;
	
	
	public void setUsuarios(List<Inventario> inventario) {
		this.inventario = inventario;
	}
	
	
	/**
	 * @param id
	 * @param cantidad
	 * @param id_provedor
	 * @param precioCompra
	 * @param fechaIngreso
	 */
	public Provedores(long id, int cantidad, long id_provedor, float precioCompra, Date fechaIngreso) {
		super();
		this.id = id;
		this.cantidad = cantidad;
		this.id_provedor = id_provedor;
		this.precioCompra = precioCompra;
		this.fechaIngreso = fechaIngreso;
	}
	
	
	
	
	
	

	public Provedores() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the cantidad
	 */
	public int getCantidad() {
		return cantidad;
	}

	/**
	 * @param cantidad the cantidad to set
	 */
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	/**
	 * @return the id_provedor
	 */
	public long getId_provedor() {
		return id_provedor;
	}

	/**
	 * @param id_provedor the id_provedor to set
	 */
	public void setId_provedor(long id_provedor) {
		this.id_provedor = id_provedor;
	}

	/**
	 * @return the precioCompra
	 */
	public float isPrecioCompra() {
		return precioCompra;
	}

	/**
	 * @param precioCompra the precioCompra to set
	 */
	public void setPrecioCompra(float precioCompra) {
		this.precioCompra = precioCompra;
	}

	/**
	 * @return the fechaIngreso
	 */
	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	/**
	 * @param fechaIngreso the fechaIngreso to set
	 */
	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

}
