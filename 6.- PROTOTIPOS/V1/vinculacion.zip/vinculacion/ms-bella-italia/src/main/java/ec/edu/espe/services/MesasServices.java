package ec.edu.espe.services;

import java.util.List;

import ec.edu.espe.modelo.Mesas;

public interface MesasServices {

	Mesas saveMesas(Mesas objMesas) throws Exception;

	List<Mesas> listAll();

	 Mesas findByNumero(int numero);

	    void deleteMesas(int id);

	    Mesas updateMesas(int id, Mesas objMesas);

	    List<Mesas> findByTexto(String texto); // Método para buscar por texto
}
