package ec.edu.espe.servicesimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ec.edu.espe.modelo.Provedores;
import ec.edu.espe.repository.ProvedoresRepository;
import ec.edu.espe.services.ProvedoresServices;


@Service
public class ProvedoresServicesImpl  implements ProvedoresServices{

	@Override
	public Provedores saveProvedores(Provedores objProvedores) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Autowired
    private ProvedoresRepository provedoresRepository;
    
    @Override
    public List<Provedores> listAll() {
        return provedoresRepository.findAll();
    }
    
    @Override
    public Optional<Provedores> findById(Long id) {
        return provedoresRepository.findById(id);
    }
    
    @Override
    public Provedores save(Provedores provedores) { 
        return provedoresRepository.save(provedores);
    }
    
    @Override
    public Provedores update(Provedores provedores) {
        return provedoresRepository.save(provedores);
    }
    
    @Override
    public void delete(Long id) {
        provedoresRepository.deleteById(id);
    }
    
    @Override
    public List<Provedores> findByNombre(String nombre) {
        return provedoresRepository.findByNombre(nombre);
    }

	
}
