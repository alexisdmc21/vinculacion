package ec.edu.espe.modelo;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "pedidos")
@NoArgsConstructor
@AllArgsConstructor


public class Pedidos {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_pedido;
	
	@Column(name = "Pedidos")
	private long cliente;
	private long mesa;
	private Date fechaPedido;
	private String estado; //activo, en proceso, inactivo, entregado
	
	
	@OneToMany
	private List<Usuario> usuarios;
	
	@ManyToOne
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;
	
	@ManyToOne
	@JoinColumn(name = "id_mesa")
	private Mesas mesas;
	
	@JoinColumn (name = " id_total")
	private double total;
	
	
	
	
	
	/**
	 * @param id_pedido
	 * @param cliente
	 * @param mesa
	 * @param fechaPedido
	 * @param estado
	 * @param usuarios
	 * @param usuario
	 * @param mesas
	 * @param total
	 */
	public Pedidos(long id_pedido, long cliente, long mesa, Date fechaPedido, String estado, List<Usuario> usuarios,
			Usuario usuario, Mesas mesas, double total) {
		this.id_pedido = id_pedido;
		this.cliente = cliente;
		this.mesa = mesa;
		this.fechaPedido = fechaPedido;
		this.estado = estado;
		this.usuarios = usuarios;
		this.usuario = usuario;
		this.mesas = mesas;
		this.total = total;
	}




	/**
	 * @return the id_pedido
	 */
	public long getId_pedido() {
		return id_pedido;
	}




	/**
	 * @param id_pedido the id_pedido to set
	 */
	public void setId_pedido(long id_pedido) {
		this.id_pedido = id_pedido;
	}




	/**
	 * @return the usuarios
	 */
	public List<Usuario> getUsuarios() {
		return usuarios;
	}




	/**
	 * @param usuarios the usuarios to set
	 */
	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}




	/**
	 * @return the usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}




	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}




	/**
	 * @return the mesas
	 */
	public Mesas getMesas() {
		return mesas;
	}




	/**
	 * @param mesas the mesas to set
	 */
	public void setMesas(Mesas mesas) {
		this.mesas = mesas;
	}




	/**
	 * @return the Usuario
	 */
	public long getCliente() {
		return cliente;
	}
	/**
	 * @param Usuario the Usuario to set
	 */
	public void setCliente(long cliente) {
		this.cliente = cliente;
	}
	/**
	 * @return the mesa
	 */
	public long getMesa() {
		return mesa;
	}
	/**
	 * @param mesa the mesa to set
	 */
	public void setMesa(long mesa) {
		this.mesa = mesa;
	}
	/**
	 * @return the fechaPedido
	 */
	public Date getFechaPedido() {
		return fechaPedido;
	}
	/**
	 * @param fechaPedido the fechaPedido to set
	 */
	public void setFechaPedido(Date fechaPedido) {
		this.fechaPedido = fechaPedido;
	}
	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}




	/**
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}




	/**
	 * @param total the total to set
	 */
	public void setTotal(double total) {
		this.total = total;
	}
	
	
	
	
	
}
