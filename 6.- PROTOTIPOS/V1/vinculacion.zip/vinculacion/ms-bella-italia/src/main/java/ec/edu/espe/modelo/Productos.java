package ec.edu.espe.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "productos")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Productos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name = "id_Productos")
	private long id_productos;
	
	@Column(name = "Tipo")
	private String nombre;
	
	@Column (name ="descripcion")
	private String descripcion;
	
	@Column (name = "precio")
	private float precio;
	
	@Column (name = "cantidad")
	private int cantidad;

	/**
	 * @param id_productos
	 * @param nombre
	 * @param descripcion
	 * @param precio
	 * @param cantidad
	 */
	public Productos(long id_productos, String nombre, String descripcion, float precio, int cantidad) {
		this.id_productos = id_productos;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.precio = precio;
		this.cantidad = cantidad;
	}
	
	

	/**
	 * @param nombre
	 * @param descripcion
	 * @param precio
	 * @param cantidad
	 */
	public Productos(String nombre, String descripcion, float precio, int cantidad) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.precio = precio;
		this.cantidad = cantidad;
	}



	/**
	 * @return the id_productos
	 */
	public long getId_productos() {
		return id_productos;
	}

	/**
	 * @param id_productos the id_productos to set
	 */
	public void setId_productos(long id_productos) {
		this.id_productos = id_productos;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	
	

	/**
	 * @return the precio
	 */
	public float getPrecio() {
		return precio;
	}



	/**
	 * @param precio the precio to set
	 */
	public void setPrecio(float precio) {
		this.precio = precio;
	}



	/**
	 * @return the cantidad
	 */
	public int getCantidad() {
		return cantidad;
	}

	/**
	 * @param cantidad the cantidad to set
	 */
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
