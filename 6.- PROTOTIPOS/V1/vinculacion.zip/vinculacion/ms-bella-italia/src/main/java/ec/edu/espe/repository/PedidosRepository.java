package ec.edu.espe.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.espe.modelo.Pedidos;

public interface PedidosRepository extends JpaRepository <Pedidos, Long>{

	List<Pedidos> findByClienteContainingOrDetalleContaining(String clienteText, String detalleText);
	
 
	
}
