package ec.edu.espe.services;

import java.util.List;
import java.util.Optional;

import ec.edu.espe.modelo.Inventario;

public interface InventarioServices {

	Inventario saveInventario(Inventario objInventario) throws Exception;

	List<Inventario> listAll();

	Optional<Inventario> findById(Long id);
	
	Inventario save(Inventario inventario);
     
	void deleteById(Long id);
	
    boolean existsById(Long id);
       
    List<Inventario> findByNombre(String nombre); // Método para buscar por nombre
}
