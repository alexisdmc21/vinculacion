package ec.edu.espe.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.espe.modelo.Provedores;

public interface ProvedoresRepository extends JpaRepository <Provedores, Long> {

	    List<Provedores> findByNombre(String nombre); // Método para buscar por nombre
	

}
