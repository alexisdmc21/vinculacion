package ec.edu.espe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsBellaItaliaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsBellaItaliaApplication.class, args);
	}

}
