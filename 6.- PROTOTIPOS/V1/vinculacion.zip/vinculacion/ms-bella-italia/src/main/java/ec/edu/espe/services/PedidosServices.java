package ec.edu.espe.services;

import java.util.List;
import java.util.Optional;

import ec.edu.espe.modelo.Pedidos;

public interface PedidosServices {

	Pedidos savePedidos(Pedidos objPedidos) throws Exception;

	List<Pedidos> listAll();


    Optional<Pedidos> findById(String id);

    Pedidos save(Pedidos pedido);

    void delete(String id);
    
    boolean existsById(Long id);

    List<Pedidos> searchByText(String text);
    
    
}
