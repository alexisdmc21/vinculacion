package ec.edu.espe.ms_bella_italia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsBellaItaliaApplicationTests {

	@Test
	void contextLoads() {
	}

}
