document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("login-form");

    form.addEventListener("submit", function(event) {
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        // Verificar si los campos están vacíos
        if (!username || !password) {
            alert("Por favor, complete todos los campos.");
            event.preventDefault(); // Evitar que el formulario se envíe automáticamente
        }
    });
});
