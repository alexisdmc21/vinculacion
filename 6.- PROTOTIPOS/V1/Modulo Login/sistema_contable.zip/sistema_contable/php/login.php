<?php
session_start();

// Conectar a la base de datos
$conn = new mysqli('localhost', 'root', '', 'sistema_contable');

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

// Consulta para verificar las credenciales
$sql = "SELECT * FROM usuarios WHERE Nombre_usuario = ? AND Contraseña = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Error en la consulta: " . $conn->error);
}
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Usuario encontrado, iniciar sesión
    $_SESSION['username'] = $username;
    header("Location: ../principal.html"); // Redirige a la página principal
    exit();
} else {
    // Usuario no encontrado, mostrar error y redirigir al login
    echo "<script>
            alert('Usuario o contraseña incorrectos.');
            window.location.href = '../index.html';
          </script>";
}

$stmt->close();
$conn->close();
?>