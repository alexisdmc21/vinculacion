<?php
$conn = new mysqli('localhost', 'root', '', 'sistema_contable');

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
} else {
    echo "Conexión exitosa!";
}

$conn->close();
?>